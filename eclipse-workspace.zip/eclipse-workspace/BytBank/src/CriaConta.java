
public class CriaConta {

	public static void main(String[] args) {
		// Criando a primeira conta.
		Conta primeiraConta = new Conta();
		primeiraConta.saldo = 200;
		System.out.println("saldo Primeira Conta " + primeiraConta.saldo + " Reais");
		primeiraConta.saldo += 100;
		System.out.println("Agora a Primeira conta tem " + primeiraConta.saldo + " Reais");

		// Segunda conta fazendo referencia a primeira conta.
		Conta segundaConta = primeiraConta;
		segundaConta.saldo = 50;
		System.out.println("Agora A Segunda conta tem " + segundaConta.saldo + " Reais");
		System.out.println("Primeira Conta " + primeiraConta.saldo + " Reais");

		// craindo terceira conta para testar funcionalidade deposito e saque.
		Conta terceiraConta = new Conta();
		terceiraConta.saldo = 100;
		System.out.println("Agora A Terceira conta tem " + terceiraConta.saldo + " Reais");
		terceiraConta.deposita(200);
		System.out.println("Tranferecia feita com susseso. Saldo " + terceiraConta.saldo + " Reais");
		if (terceiraConta.saca(50)) {
			System.out.println("Saque feito com Sucesso. Saldo " + terceiraConta.saldo);
		} else {
			System.out.println("Saldo insuficiente");
		}

		// quarta conta para teste transferencia
		Conta quartaConta = new Conta();
		quartaConta.saldo = 1300;
		System.out.println("quarte conta tem R$" + quartaConta.saldo);
		if(quartaConta.transfere(500, terceiraConta)) {
			System.out.println("transferencia feita com sucesso. Seu saldo atual � R$" + quartaConta.saldo);
		} else {
			System.out.println("Saldo insuficiente");
		}
		System.out.println("Saldo 3� conta" + terceiraConta.saldo);
		

	}
}
