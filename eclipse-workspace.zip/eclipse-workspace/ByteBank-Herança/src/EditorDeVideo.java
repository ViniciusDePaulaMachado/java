
public class EditorDeVideo extends Funcionario { 

	public double getBonifica�ao() {
		System.out.println("Bonus editor de video");
		return 150;
	}
}
