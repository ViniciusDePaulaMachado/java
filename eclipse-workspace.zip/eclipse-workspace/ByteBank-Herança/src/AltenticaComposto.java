
public class AltenticaComposto {
	
	private int senha;
		
	public void setSenha(int senha) {
		this.senha = senha;
		
	}

	public boolean Autentica(int senha) {
		if(this.senha == senha) {
			return true;
		} else {

			return false;
		}
	}

}
