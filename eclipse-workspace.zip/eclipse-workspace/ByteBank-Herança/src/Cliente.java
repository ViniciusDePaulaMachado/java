
public class Cliente implements Autenticavel {
	

	private AltenticaComposto autenticador;

	public Cliente() {
		this.autenticador = new AltenticaComposto();
	}

	@Override
	public void setSenha(int senha) {
		this.autenticador.setSenha(senha);;	
	}

	@Override
	public boolean Autentica(int senha) {
		return autenticador.Autentica(senha);
	}

}
