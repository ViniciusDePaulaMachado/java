
public class Administrador extends Funcionario implements Autenticavel {

	private AltenticaComposto autenticador;

	public Administrador() {
		this.autenticador = new AltenticaComposto();
	}
	
	@Override
	public double getBonifica�ao() {
		return 50;
	}

	@Override
	public void setSenha(int senha) {
		this.autenticador.setSenha(senha);
	}

	@Override
	public boolean Autentica(int senha) {
		return autenticador.Autentica(senha);
	}

}
