
public class Designer extends Funcionario {

	public double getBonifica�ao() {
		System.out.println("Bonus Designer");
		return 200;
	}

}
