
public abstract interface Autenticavel {

	public abstract void setSenha(int Senha);

	public abstract boolean Autentica(int senha);

}
