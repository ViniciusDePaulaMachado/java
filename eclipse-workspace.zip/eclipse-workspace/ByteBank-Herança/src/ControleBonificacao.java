
public class ControleBonificacao {

	private double soma;

	public void registra(Funcionario f) {

		double bonificacao = f.getBonifica�ao();
		this.soma = this.soma + bonificacao;
	}

	public double getSoma() {
		
		return this.soma;
	}

}
