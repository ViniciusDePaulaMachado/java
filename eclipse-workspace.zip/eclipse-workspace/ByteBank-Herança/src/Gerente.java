
public class Gerente extends Funcionario implements Autenticavel {

	private AltenticaComposto autenticador;
	
	public Gerente() {
		 this.autenticador = new AltenticaComposto();
	}

	public double getBonifica�ao() {
		System.out.println("Bonus gerente");
		return super.getSalario();
	}

	public void setSenha(int senha) {
		autenticador.setSenha(senha);
	}

	public boolean Autentica(int senha) {
		return this.autenticador.Autentica(senha);
	}
	
}
