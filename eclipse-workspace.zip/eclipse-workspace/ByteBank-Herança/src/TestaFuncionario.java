
public class TestaFuncionario {

	public static void main(String[] args) {

//		Gerente f2 = new Gerente();
//		f2.setCpf("123123123123");
//		f2.setNome("vinicius2");
//		f2.setSalario(5000.0);
//		
//		System.out.println("Salario f2 R$ " + f2.getSalario());
//		System.out.println("bonus f2 " + f2.getBonifica�ao() + " Reais");
//
//		f2.setSenha(2222);
//		boolean senha = f2.Autentica(2222);
//		System.out.println(senha);
		
		Gerente g = new Gerente();
		g.setSenha(2222);
		
		Cliente c = new Cliente();
		c.setSenha(2222);
		
		SistemaInterno si = new SistemaInterno();
		si.autentica(g);
		si.autentica(c);
	}
}
