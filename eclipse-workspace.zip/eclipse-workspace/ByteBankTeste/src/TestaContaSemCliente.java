
public class TestaContaSemCliente {
	public static void main(String[] args) {
		
		Conta contaDaPaula = new Conta(1333,444);
		
		Cliente paula = new Cliente();
		
		contaDaPaula.titular = new Cliente();
		contaDaPaula.titular.setNome("paula"); 
		System.out.println(contaDaPaula.titular.getNome());
	}

}
