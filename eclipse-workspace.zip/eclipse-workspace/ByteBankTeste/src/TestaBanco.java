
public class TestaBanco {

	public static void main(String[] args) {

		Cliente paulo = new Cliente();
		paulo.setNome("Paula Silveira");
		paulo.setCpf("123.456.789-01");
		paulo.setProfissao("programador");
		System.out.println(paulo.getNome() + " " + paulo.getCpf() + " " + paulo.getProfissao());
		
		Conta contaDoPaulo = new Conta(1334,52);
		contaDoPaulo.titular = paulo;
		contaDoPaulo.deposita(200);

		
		System.out.println("R$" + contaDoPaulo.getSaldo());
	}

}
