
public class EclipseInstalado {

	public static void main(String[] args) {
		
		System.out.println("Vinicius");
		
	}

}
