
public class TestaCarecteres {

	public static void main(String[] args) {
		
			
		char letraA = 'a';
		System.out.println(letraA);
		
		char valor = 65;
		System.out.println(valor);
		
		valor = (char) (valor + 1);
		System.out.println(valor);
		
		String palavra = "Curso Alura ";
		System.out.println(palavra);
		
		palavra = palavra + 2020;
		System.out.println(palavra);
	}
}
