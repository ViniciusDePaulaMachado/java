
public class WhileTeste {

	public static void main(String[] args) {

		int limitador = 0;

		while (limitador <= 10) {
			System.out.println(limitador);
			limitador++;
		}
	}
}