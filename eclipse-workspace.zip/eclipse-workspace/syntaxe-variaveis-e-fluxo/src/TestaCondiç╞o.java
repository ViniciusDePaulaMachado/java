
public class TestaCondi��o {

	public static void main(String[] args) {

		int idade = 2;
		int quantidadePessoas = 2;
		boolean acompanhado = quantidadePessoas >= 2;

		if (idade >= 18 || acompanhado) {
			System.out.println("Voc� est� liberado.");
		} else {
			System.out.println("Voc� n�o est� liberado.");
		}
	}
}
