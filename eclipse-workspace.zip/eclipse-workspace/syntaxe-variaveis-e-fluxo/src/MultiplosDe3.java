
public class MultiplosDe3 {

	public static void main(String[] args) {
		for (int multiplica = 0; multiplica <= 100; multiplica += 3) {

			System.out.println(multiplica);
		}
	}

}
