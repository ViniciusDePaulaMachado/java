
public class TesteVariaveis {
	
	public static void main(String[] args) {
		
		System.out.println("Teste idade");
		
		
	double idade = 20.5;	
	
		System.out.println("Minha idade � " + idade);
		System.out.println();
	
	int ano = 2021;
	
	System.out.println("Eu nasci em " + (ano - idade));
	System.out.println();
	
	double salario = 1500.50;
	
	System.out.println("Meu sal�rio � " + salario + " Reais");
	System.out.println();
	System.out.println("Ganhei uma aumento de 300R$ agora meu sal�rio � " + (salario + 300) + " Reais" );
	
	
	
	}
}
