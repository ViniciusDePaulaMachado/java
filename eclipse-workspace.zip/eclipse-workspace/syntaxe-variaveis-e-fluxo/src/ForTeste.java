
public class ForTeste {

	public static void main(String[] args) {

		System.out.println("For teste");
		for (int contador = 0; contador <= 10; contador++) {

			System.out.println(contador);
		}
	}
}
