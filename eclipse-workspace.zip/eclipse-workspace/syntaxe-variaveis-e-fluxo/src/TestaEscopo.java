
public class TestaEscopo {

	public static void main(String[] args) {

		// pode entrar tando acompanhado ou se for maior de 18 anos.

		int idade = 15;

		int quantiaPessoas = 4;

		boolean acompanhado;

		if (quantiaPessoas >= 2) {

			acompanhado = true;

		} else {

			acompanhado = false;
		}

		if (idade >= 18 || acompanhado) {

			System.out.println("Voc� est� liberado");

		} else {

			System.out.println("Voc� n�o pode entrar");
		}
	}
}
