
public class TestaVariaveis {
	
	public static void main(String[] args) {
		
		double salario = 1270.50;
		int valor = (int) salario;
		
		System.out.println(valor);
		
		double numero1 = 0.1;
		double numero2 = 0.2;
		double total = numero1 + numero2;
		
		System.out.println(total);
		
		float pontoFlutuante = 3.14f;
		
		System.out.println(pontoFlutuante);
	}

}
