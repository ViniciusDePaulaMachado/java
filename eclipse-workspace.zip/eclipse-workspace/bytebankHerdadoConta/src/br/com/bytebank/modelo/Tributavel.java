package br.com.bytebank.modelo;

public interface Tributavel {
	//j� publico e abstrata por padr�o;
	double getValorImposto();

}
