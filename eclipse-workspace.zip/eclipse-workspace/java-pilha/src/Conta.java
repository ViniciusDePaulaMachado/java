
public class Conta {

	public void deposita(){}
}
